#import yfinance as yf

#ticker = "AAPL"
#data = yf.download(ticker, start="2010-01-01", auto_adjust=False)

#if "Adj Close" in data.columns:
#    print("Adj Close is available!")
#else:
#    print("Adj Close is not available, using Close instead.")

#print(data)
