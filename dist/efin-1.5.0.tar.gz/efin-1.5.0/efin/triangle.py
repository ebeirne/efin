#def triangle(n):
#    for i in range(1,n+1):
#        print(i*'*')
#triangle(5)